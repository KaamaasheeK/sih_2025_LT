import React from "react";
import { View, Text, StyleSheet } from "react-native";

export default function EventItem({ event, time, severity }) {
  return (
    <View style={styles.item}>
      <Text style={styles.event}>{event}</Text>
      <Text style={styles.time}>{time}</Text>
      <Text style={[styles.severity, severity === "High" ? styles.high : severity === "Medium" ? styles.medium : styles.low]}>
        {severity}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  item: {
    backgroundColor: "#fff",
    padding: 12,
    borderRadius: 8,
    marginBottom: 10,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  event: { fontSize: 14, fontWeight: "500", color: "#2c3e50" },
  time: { fontSize: 12, color: "#6c757d" },
  severity: { fontSize: 12, fontWeight: "bold" },
  high: { color: "#e74c3c" },
  medium: { color: "#f39c12" },
  low: { color: "#27ae60" },
});
