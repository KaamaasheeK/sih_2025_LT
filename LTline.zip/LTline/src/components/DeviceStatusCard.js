import React from "react";
import { View, Text, StyleSheet } from "react-native";

export default function DeviceStatusCard({ deviceId, location, current, voltage, status }) {
  return (
    <View style={styles.card}>
      <Text style={styles.text}>Device: {deviceId}</Text>
      <Text style={styles.text}>Location: {location}</Text>
      <Text style={styles.text}>Current: {current}</Text>
      <Text style={styles.text}>Voltage: {voltage}</Text>
      <Text style={styles.text}>Status: {status}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#fff",
    padding: 14,
    borderRadius: 10,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 6,
    marginBottom: 16,
  },
  text: { fontSize: 14, color: "#2c3e50" },
});
