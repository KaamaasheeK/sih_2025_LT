import React from "react";
import { View, Text } from "react-native";

export default function ChartPlaceholder({ title }) {
  return (
    <View
      style={{
        height: 150,
        borderWidth: 1,
        borderColor: "#ccc",
        borderRadius: 8,
        justifyContent: "center",
        alignItems: "center",
        marginBottom: 16,
        backgroundColor: "#f9f9f9",
      }}
    >
      <Text style={{ fontSize: 16, fontWeight: "bold" }}>{title}</Text>
      <Text style={{ color: "gray", fontSize: 12 }}>Chart Placeholder</Text>
    </View>
  );
}
