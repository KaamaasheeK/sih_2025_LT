// import React from "react";
// import { View, Text, FlatList, StyleSheet, TouchableOpacity } from "react-native";
// import EventItem from "../components/EventItem";

// const events = [
//   { id: "1", event: "Line break detected", time: "12:01 PM", severity: "High" },
//   { id: "2", event: "Connection lost", time: "11:45 AM", severity: "Medium" },
//   { id: "3", event: "Low voltage", time: "11:20 AM", severity: "Low" },
//   { id: "4", event: "Line break detected", time: "10:50 AM", severity: "High" },
// ];

// export default function EventsScreen() {
//   return (
//     <View style={styles.container}>
//       <Text style={styles.title}>⚡ Events</Text>

//       <FlatList
//         data={events}
//         keyExtractor={(item) => item.id}
//         renderItem={({ item }) => (
//           <EventItem event={item.event} time={item.time} severity={item.severity} />
//         )}
//       />

//       <TouchableOpacity style={styles.exportBtn}>
//         <Text style={styles.exportText}>Export (CSV/PDF)</Text>
//       </TouchableOpacity>
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   container: { flex: 1, padding: 16, backgroundColor: "#f8f9fa" },
//   title: { fontSize: 22, fontWeight: "bold", marginBottom: 16, color: "#2c3e50" },
//   exportBtn: {
//     backgroundColor: "#2c3e50",
//     padding: 12,
//     borderRadius: 8,
//     alignItems: "center",
//     marginTop: 10,
//   },
//   exportText: { color: "#fff", fontWeight: "bold" },
// });
import React, { useEffect, useState } from "react";
import { View, Text, FlatList, StyleSheet, TouchableOpacity, ActivityIndicator } from "react-native";
import EventItem from "../components/EventItem";

export default function EventsScreen() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAlerts = () => {
      fetch("http://127.0.0.1:8000/alerts")  // backend URL
        .then((res) => res.json())
        .then((data) => {
          const formatted = data.map((item, index) => ({
            id: String(index + 1),
            event: item.event,
            time: new Date(item.time).toLocaleTimeString(),
            severity: item.severity,
          }));
          setEvents(formatted);
        })
        .catch((err) => console.error("❌ Error fetching alerts:", err))
        .finally(() => setLoading(false));
    };

    fetchAlerts();

    // refresh every 10 seconds for near real-time alerts
    const interval = setInterval(fetchAlerts, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>⚡ LT Line Alerts</Text>

      {loading ? (
        <ActivityIndicator size="large" color="#2c3e50" />
      ) : (
        <FlatList
          data={events}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <EventItem event={item.event} time={item.time} severity={item.severity} />
          )}
        />
      )}

      <TouchableOpacity style={styles.exportBtn}>
        <Text style={styles.exportText}>Export (CSV/PDF)</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: "#f8f9fa" },
  title: { fontSize: 22, fontWeight: "bold", marginBottom: 16, color: "#2c3e50" },
  exportBtn: {
    backgroundColor: "#2c3e50",
    padding: 12,
    borderRadius: 8,
    alignItems: "center",
    marginTop: 10,
  },
  exportText: { color: "#fff", fontWeight: "bold" },
});
