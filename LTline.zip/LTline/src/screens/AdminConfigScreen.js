import React, { useState } from "react";
import { View, Text, TextInput, Button, StyleSheet, Alert } from "react-native";

export default function AdminConfigScreen() {
  const [deviceId, setDeviceId] = useState("");
  const [pole, setPole] = useState("");
  const [xCoord, setXCoord] = useState("");
  const [yCoord, setYCoord] = useState("");

  const handleAddDevice = () => {
    if (!deviceId || !pole) {
      Alert.alert("Error", "Device ID and Pole are required!");
      return;
    }
    Alert.alert("Device Added", `Device ${deviceId} at ${pole} added successfully`);
    setDeviceId("");
    setPole("");
    setXCoord("");
    setYCoord("");
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Admin / Config</Text>

      <TextInput
        style={styles.input}
        placeholder="Device ID"
        value={deviceId}
        onChangeText={setDeviceId}
      />
      <TextInput
        style={styles.input}
        placeholder="Pole"
        value={pole}
        onChangeText={setPole}
      />
      <TextInput
        style={styles.input}
        placeholder="X-coordinate"
        value={xCoord}
        onChangeText={setXCoord}
        keyboardType="numeric"
      />
      <TextInput
        style={styles.input}
        placeholder="Y-coordinate"
        value={yCoord}
        onChangeText={setYCoord}
        keyboardType="numeric"
      />

      <Button title="Add Device" onPress={handleAddDevice} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "#fff",
  },
  title: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    padding: 10,
    borderRadius: 8,
    marginBottom: 12,
  },
});
