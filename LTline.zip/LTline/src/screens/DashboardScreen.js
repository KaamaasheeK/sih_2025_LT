import React from "react";
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from "react-native";
import DeviceStatusCard from "../components/DeviceStatusCard";
import EventItem from "../components/EventItem";

export default function DashboardScreen() {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>⚡ Real-time Dashboard</Text>

      {/* Map Placeholder */}
      <View style={styles.mapPlaceholder}>
        <Text style={{ color: "gray" }}>Map View (Leaflet/Mapbox integration)</Text>
      </View>

      {/* Device Status */}
      <DeviceStatusCard deviceId="Device123" location="Pole 7" current="5A" voltage="220V" status="ON" />

      {/* Quick Actions */}
      <View style={styles.actions}>
        <TouchableOpacity style={styles.button}>
          <Text style={styles.buttonText}>Send Disconnect</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.buttonOutline}>
          <Text style={styles.buttonTextOutline}>Acknowledge Event</Text>
        </TouchableOpacity>
      </View>

      {/* Recent Events */}
      <Text style={styles.sectionTitle}>Recent Events</Text>
      <EventItem event="Line break detected" time="12:01 PM" severity="High" />
      <EventItem event="Connection lost" time="11:45 AM" severity="Medium" />
      <EventItem event="Low voltage" time="11:20 AM" severity="Low" />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: "#f8f9fa" },
  title: { fontSize: 22, fontWeight: "bold", marginBottom: 16, color: "#2c3e50" },
  mapPlaceholder: {
    height: 180,
    backgroundColor: "#e9ecef",
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 16,
  },
  actions: { flexDirection: "row", justifyContent: "space-around", marginVertical: 12 },
  button: { backgroundColor: "#e74c3c", padding: 12, borderRadius: 8, flex: 1, marginRight: 8 },
  buttonText: { color: "#fff", textAlign: "center", fontWeight: "bold" },
  buttonOutline: {
    borderWidth: 1,
    borderColor: "#2c3e50",
    padding: 12,
    borderRadius: 8,
    flex: 1,
    marginLeft: 8,
  },
  buttonTextOutline: { color: "#2c3e50", textAlign: "center", fontWeight: "bold" },
  sectionTitle: { fontSize: 18, fontWeight: "600", marginVertical: 10, color: "#2c3e50" },
});
