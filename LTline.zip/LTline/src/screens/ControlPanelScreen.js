import React from "react";
import { View, Text, FlatList, TouchableOpacity, Alert, StyleSheet } from "react-native";

const devices = [
  { id: "Device123", location: "Pole 7", status: "ON" },
  { id: "Device456", location: "Pole 8", status: "OFF" },
];

export default function ControlPanelScreen() {
  const handleDisconnect = (deviceId) => {
    Alert.alert("Confirm", `Are you sure to disconnect ${deviceId}?`, [
      { text: "Cancel", style: "cancel" },
      { text: "Yes", onPress: () => console.log("Disconnected:", deviceId) },
    ]);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>⚡ Control Panel</Text>

      <FlatList
        data={devices}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.row}>
            <Text style={styles.text}>{item.id} ({item.location})</Text>
            <TouchableOpacity
              style={styles.button}
              onPress={() => handleDisconnect(item.id)}
            >
              <Text style={styles.buttonText}>
                {item.status === "ON" ? "Disconnect" : "Reconnect"}
              </Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: "#f8f9fa" },
  title: { fontSize: 22, fontWeight: "bold", marginBottom: 16, color: "#2c3e50" },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    backgroundColor: "#fff",
    padding: 12,
    borderRadius: 8,
    marginBottom: 10,
  },
  text: { fontSize: 14, color: "#2c3e50" },
  button: { backgroundColor: "#e74c3c", padding: 8, borderRadius: 6 },
  buttonText: { color: "#fff", fontWeight: "bold" },
});
