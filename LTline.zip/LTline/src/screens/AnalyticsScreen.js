import React from "react";
import { View, Text, StyleSheet } from "react-native";
import ChartPlaceholder from "../components/ChartPlaceholder";

export default function AnalyticsScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>📊 Analytics</Text>

      <ChartPlaceholder title="Line Break Frequency" />
      <ChartPlaceholder title="Average Response Time" />
      <ChartPlaceholder title="Success Rate of Detection" />

      <Text style={styles.logsTitle}>Logs</Text>
      <View style={styles.logItem}>
        <Text style={styles.logText}>[12:01 PM] Disconnect command issued by Admin</Text>
      </View>
      <View style={styles.logItem}>
        <Text style={styles.logText}>[11:45 AM] Event detected (Connection lost)</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: "#f8f9fa" },
  title: { fontSize: 22, fontWeight: "bold", marginBottom: 16, color: "#2c3e50" },
  logsTitle: { fontSize: 18, fontWeight: "600", marginTop: 20, marginBottom: 8 },
  logItem: { backgroundColor: "#fff", padding: 10, borderRadius: 6, marginBottom: 6 },
  logText: { fontSize: 14, color: "#2c3e50" },
});
