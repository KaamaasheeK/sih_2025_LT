import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import DashboardScreen from "../screens/DashboardScreen";
import EventsScreen from "../screens/EventsScreen";
import ControlPanelScreen from "../screens/ControlPanelScreen";
import AnalyticsScreen from "../screens/AnalyticsScreen";
import AdminConfigScreen from "../screens/AdminConfigScreen";
import { Ionicons } from "@expo/vector-icons";

const Tab = createBottomTabNavigator();

export default function BottomTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color, size }) => {
          let iconName;
          if (route.name === "Dashboard") iconName = "speedometer";
          else if (route.name === "Events") iconName = "alert-circle";
          else if (route.name === "Control") iconName = "power";
          else if (route.name === "Analytics") iconName = "analytics";
          else if (route.name === "Admin") iconName = "settings";
          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: "#2c3e50",
        tabBarInactiveTintColor: "gray",
      })}
    >
      <Tab.Screen name="Dashboard" component={DashboardScreen} />
      <Tab.Screen name="Events" component={EventsScreen} />
      <Tab.Screen name="Control" component={ControlPanelScreen} />
      <Tab.Screen name="Analytics" component={AnalyticsScreen} />
      <Tab.Screen name="Admin" component={AdminConfigScreen} />
    </Tab.Navigator>
  );
}
